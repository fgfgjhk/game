gdjs.gameoverCode = {};
gdjs.gameoverCode.localVariables = [];


gdjs.gameoverCode.eventsList0 = function(runtimeScene) {

};

gdjs.gameoverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.gameoverCode.eventsList0(runtimeScene);


return;

}

gdjs['gameoverCode'] = gdjs.gameoverCode;
